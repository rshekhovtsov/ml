from xor import XORDataSet, SequentialXORDataSet
from anbncn import AnBnCnDataSet
from parity import ParityDataSet