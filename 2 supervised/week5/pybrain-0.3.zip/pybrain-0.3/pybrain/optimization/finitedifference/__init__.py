from fd import FiniteDifferences
from spsa import SimpleSPSA
from pgpe import PGPE