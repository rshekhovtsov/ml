from trainer import Trainer
from backprop import BackpropTrainer
from rprop import RPropMinusTrainer
