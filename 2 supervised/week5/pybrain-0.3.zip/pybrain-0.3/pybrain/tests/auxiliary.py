#! /usr/bin/env python2.5
# -*- coding: utf-8 -*-

__author__ = 'Justin Bayer, bayer.justin@googlemail.com'
__version__ = '$Id$'


""""This module is a place to hold functionality that _has_ to be outside of a 
test module but is required by it."""
